import { PortfolioProject, ServiceItem } from '../types';

export const BRAND_INFO = {
  name: 'srwebLab',
  displayName: 'S&R WebLab',
  slogan: 'Sites que geram resultado',
  impactTagline: 'Tecnologia que coloca seu negócio em outro nível.',
  region: 'Brasil (Atendimento Nacional)',
  phoneRaw: '5524992694999',
  phoneDisplay: '+55 24 99269-4999',
  instagramHandle: '@srweblab',
  instagramUrl: 'https://instagram.com/srweblab',
  email: 'contato@srweblab.com.br',
  differentiator: 'Entrego no mesmo dia',
  primaryCtaText: 'Solicitar um site para minha empresa',
};

export const getWhatsAppLink = (customMessage?: string) => {
  const defaultText = `Olá! Gostaria de solicitar um orçamento para o meu site com a srwebLab.`;
  const message = customMessage || defaultText;
  return `https://wa.me/${BRAND_INFO.phoneRaw}?text=${encodeURIComponent(message)}`;
};

export const ABOUT_CONTENT = {
  title: 'Sobre a srwebLab',
  subtitle: 'Transformamos ideias em experiências digitais.',
  paragraphs: [
    'Na S&R WebLab, transformamos ideias em experiências digitais.',
    'Criamos sites modernos, responsivos e personalizados para diferentes nichos, unindo design, tecnologia e funcionalidade para fortalecer a presença digital de cada negócio.',
    'Sua ideia merece um espaço na web. Nós construímos esse espaço.',
  ],
  stats: [
    { value: '24h', label: 'Entrega Express Disponível', caption: 'No mesmo dia' },
    { value: '+99.4%', label: 'Pontuação no Google PageSpeed', caption: 'Velocidade máxima' },
    { value: '100%', label: 'Responsivo e Otimizado', caption: 'Mobile & Desktop' },
    { value: '3.4x', label: 'Mais Conversão Média', caption: 'Foco em faturamento' },
  ],
  pillars: [
    {
      title: 'Design de Alto Padrão',
      desc: 'Interfaces elegantes que constroem autoridade imediata para sua marca diante dos concorrentes.',
    },
    {
      title: 'Alta Conversão',
      desc: 'Copywriting estratégico, botões de ação certeiros e caminhos simplificados até o WhatsApp.',
    },
    {
      title: 'Velocidade Extrema',
      desc: 'Carregamento ultrarrápido em menos de 1 segundo para nunca perder clientes por lentidão.',
    },
  ],
};

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: 'landing-pages',
    title: 'Landing Pages de Alta Conversão',
    category: 'Vendas & Tráfego Pago',
    description:
      'Páginas de aterrissagem focadas exclusivamente em converter visitantes em clientes pagantes. Ideais para campanhas no Google e Meta Ads com conexão direta para o WhatsApp da sua equipe comercial.',
    features: [
      'Copywriting persuasivo orientado a vendas',
      'Integração direta com WhatsApp e Pixel de rastreio',
      'Carregamento instantâneo (< 1s)',
      'Otimização completa para telas de smartphones',
    ],
    deliveryTime: 'Opção de Entrega no Mesmo Dia',
    isHighlight: true,
  },
  {
    id: 'sites-institucionais',
    title: 'Sites Institucionais Corporativos',
    category: 'Autoridade & Marca',
    description:
      'Apresente sua empresa com sofisticação, profissionalismo e credibilidade inquestionável. Estrutura multipáginas com apresentação de serviços, equipe, cases e formulários inteligentes.',
    features: [
      'Identidade visual personalizada e moderna',
      'Painel intuitivo para gerenciamento de conteúdo',
      'SEO técnico para indexação prioritária no Google',
      'Seções estruturadas para autoridade de marca',
    ],
    deliveryTime: 'Entrega Express em 24h a 48h',
  },
  {
    id: 'lojas-virtuais',
    title: 'E-commerce & Catálogos Digitais',
    category: 'Vendas Online',
    description:
      'Lojas modernas, seguras e com fluxo de checkout simplificado. Catálogos interativos com cálculo de frete, pagamento via PIX/Cartão e envio automatizado de pedidos.',
    features: [
      'Checkout sem fricção com foco em finalizar pedidos',
      'Integração com meios de pagamento e logística',
      'Gestão simplificada de produtos e estoque',
      'Interface mobile-first fluida e rápida',
    ],
    deliveryTime: 'Entrega rápida e estruturada',
  },
  {
    id: 'paginas-vendas',
    title: 'Portais de Vendas & Infoprodutos',
    category: 'Escala Comercial',
    description:
      'Ambientes preparados para suportar milhares de acessos simultâneos sem quedas, com gatilhos de urgência, depoimentos em carrossel e checkout de alta conversão.',
    features: [
      'Infraestrutura em nuvem de alta disponibilidade',
      'Gatilhos psicológicos e provas sociais dinâmicas',
      'Design responsivo sob medida para o nicho',
      'Proteção e segurança SSL inclusa',
    ],
    deliveryTime: 'Opção de entrega prioritária',
  },
];

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'b2b-fintech',
    title: 'Nexus Capital B2B',
    client: 'Nexus Consultoria Empresarial',
    segment: 'B2B & Finanças',
    metric: '+184%',
    metricLabel: 'Novos Leads Qualificados',
    description:
      'Redesenho completo da plataforma institucional com foco em geração de leads B2B corporativos e agendamento de reuniões consultivas.',
    tags: ['Landing Page', 'Alta Conversão', 'B2B'],
    image: '/src/assets/images/portfolio_project_fintech_1791174458776.jpg',
    aspectRatio: '4:3',
    deliverySpeed: 'Entregue em 24 horas',
  },
  {
    id: 'lux-ecommerce',
    title: 'Aura Maison Lifestyle',
    client: 'Aura Concept Store',
    segment: 'Moda & Luxo',
    metric: '+230%',
    metricLabel: 'Aumento em Vendas Diretas',
    description:
      'E-commerce minimalista com experiência de compra fluida, checkout com 1 clique e catálogo com estética visual de alto padrão.',
    tags: ['E-commerce', 'Mobile First', 'Moda'],
    image: '/src/assets/images/portfolio_project_ecommerce_1791174467730.jpg',
    aspectRatio: '4:3',
    deliverySpeed: 'Entregue em tempo recorde',
  },
  {
    id: 'corp-services',
    title: 'Apex Prime Engenharia',
    client: 'Grupo Apex Soluções',
    segment: 'Serviços Corporativos',
    metric: '0.8s',
    metricLabel: 'Tempo de Carregamento Médio',
    description:
      'Site institucional corporativo para apresentação de grandes obras e atração de novos contratos governamentais e privados.',
    tags: ['Institucional', 'SEO Google', 'Engenharia'],
    image: '/src/assets/images/portfolio_project_corporate_1791174476209.jpg',
    aspectRatio: '4:3',
    deliverySpeed: 'Entrega no mesmo dia solicitada',
  },
];

/* Exact pricing data from the client's uploaded reference image */
export interface OfficialPlan {
  id: string;
  name: string;
  price: string;
  cents: string;
  bannerText: string;
  isPopular?: boolean;
  features: string[];
  mockupTitle: string;
  mockupSubtitle?: string;
  buttonText: string;
}

export const OFFICIAL_PLANS: OfficialPlan[] = [
  {
    id: 'site-simples',
    name: 'SITE SIMPLES',
    price: '150',
    cents: ',00',
    bannerText: 'PLANO IDEAL PARA COMEÇAR',
    isPopular: false,
    mockupTitle: 'Sua marca aqui',
    buttonText: 'Saiba mais',
    features: [
      '1 Página (Landing Page)',
      'Design Responsivo (Computador, Tablet e Celular)',
      'Formulário de Contato',
      'Integração com WhatsApp',
      'Otimização Básica de SEO',
    ],
  },
  {
    id: 'site-essencial',
    name: 'SITE ESSENCIAL',
    price: '300',
    cents: ',00',
    bannerText: 'MAIS FUNCIONALIDADES PARA O SEU CRESCIMENTO',
    isPopular: true,
    mockupTitle: 'Seu negócio mais forte na internet',
    buttonText: 'Ver Serviços',
    features: [
      'Até 5 Páginas (Home, Sobre, Serviços, Contato e Blog)',
      'Design Personalizado',
      'Formulário de Contato Avançado',
      'Integração com WhatsApp',
      'Otimização de SEO Completa',
      'Google Analytics (básico)',
    ],
  },
  {
    id: 'site-premium',
    name: 'SITE PREMIUM',
    price: '500',
    cents: ',00',
    bannerText: 'TUDO O QUE VOCÊ PRECISA PARA DOMINAR O DIGITAL',
    isPopular: false,
    mockupTitle: 'Transforme seu negócio em resultados',
    buttonText: 'Saiba mais',
    features: [
      'Até 10 Páginas (Personalizadas)',
      'Design 100% Exclusivo e Moderno',
      'Blog (Gerenciamento de Conteúdo)',
      'Formulário de Contato Avançado',
      'Integrações (WhatsApp, Redes Sociais, CRM, etc.)',
      'Otimização de SEO Avançada',
      'Suporte Prioritário',
      'Painel de Gerenciamento (Fácil e Intuitivo)',
    ],
  },
];

export const TRUST_BENEFITS = [
  {
    id: 'ssl',
    title: 'SITES SEGUROS',
    desc: 'com certificado SSL',
  },
  {
    id: 'speed',
    title: 'CARREGAMENTO',
    desc: 'SUPER RÁPIDO',
  },
  {
    id: 'responsive',
    title: '100% RESPONSIVO',
    desc: 'em todos os dispositivos',
  },
  {
    id: 'support',
    title: 'SUPORTE ESPECIALIZADO',
    desc: 'antes e depois da entrega',
  },
];
