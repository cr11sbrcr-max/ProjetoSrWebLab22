export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  description: string;
  features: string[];
  deliveryTime: string;
  isHighlight?: boolean;
}

export interface PortfolioProject {
  id: string;
  title: string;
  client: string;
  segment: string;
  metric: string;
  metricLabel: string;
  description: string;
  tags: string[];
  image: string;
  aspectRatio: string;
  fullUrl?: string;
  deliverySpeed: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  badge?: string;
  isPopular?: boolean;
  price: string;
  period: string;
  tagline: string;
  deliveryTime: string;
  features: string[];
  idealFor: string;
}

export interface ContactFormData {
  name: string;
  phone: string;
  company: string;
  serviceType: string;
  urgency: 'same_day' | 'normal';
  message: string;
}
