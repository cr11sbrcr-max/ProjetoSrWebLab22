import React, { useState } from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
}

export function Logo({ className = '', size = 'md', showSubtitle = false }: LogoProps) {
  const [imageError, setImageError] = useState(false);

  const heightClasses = {
    sm: 'h-10 sm:h-12',
    md: 'h-12 sm:h-14',
    lg: 'h-24 sm:h-32',
    xl: 'h-36 sm:h-48',
  }[size];

  return (
    <div className={`inline-flex flex-col items-center justify-center select-none ${className}`}>
      {!imageError ? (
        <img
          src="/src/assets/images/srweblab_brand_logo_1791175299820.jpg"
          alt="srwebLab - Sites que geram resultado"
          className={`${heightClasses} w-auto object-contain filter drop-shadow-[0_0_20px_rgba(255,85,0,0.3)] transition-transform duration-300 hover:scale-[1.02]`}
          onError={() => setImageError(true)}
          referrerPolicy="no-referrer"
        />
      ) : (
        /* Vector fallback if image cannot be rendered */
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-1 font-display font-extrabold text-white text-xl">
            <span className="text-white">srweb</span>
            <span className="text-brand">LaB</span>
          </div>
          <span className="text-[10px] text-brand tracking-widest uppercase font-bold mt-0.5">
            Sites que geram resultado
          </span>
        </div>
      )}
    </div>
  );
}
