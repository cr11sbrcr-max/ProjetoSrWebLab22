import { useState } from 'react';
import { Menu, X, ArrowUpRight, MessageCircle } from 'lucide-react';
import { BRAND_INFO, getWhatsAppLink } from '../data/content';
import { Logo } from './Logo';

interface HeaderProps {
  onOpenContactModal?: () => void;
}

export function Header({ onOpenContactModal }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Planos', href: '#planos' },
    { label: 'Contato', href: '#contato' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-canvas/90 border-b border-surface-border transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Zone 1: Single element Brand Wordmark with official Logo */}
        <a 
          href="#inicio" 
          className="group flex items-center gap-3 focus-visible:outline-none"
          aria-label="srwebLab Página Inicial"
        >
          <Logo size="md" />
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav 
          className="hidden md:flex items-center gap-8 text-sm font-medium text-canvas-muted"
          aria-label="Navegação Principal"
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="hover:text-white transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-brand hover:after:w-full after:transition-all after:duration-200"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          {/* Instagram link */}
          <a
            href={BRAND_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram da S&R WebLab"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold tracking-wide text-canvas-muted hover:text-white rounded-lg border border-surface-border hover:border-canvas-muted transition-colors whitespace-nowrap"
          >
            <span>{BRAND_INFO.instagramHandle}</span>
            <ArrowUpRight className="w-3.5 h-3.5 opacity-70" aria-hidden="true" />
          </a>

          {/* Primary CTA */}
          <a
            href={getWhatsAppLink('Olá! Acessei o site da S&R WebLab e gostaria de solicitar um orçamento para minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-brand hover:bg-brand-hover active:bg-brand-active rounded-lg shadow-subtle hover:shadow-brand-glow transition-all duration-200 whitespace-nowrap focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-canvas"
          >
            <MessageCircle className="w-4 h-4" aria-hidden="true" />
            <span>Solicitar Site</span>
          </a>

          {/* Mobile hamburger button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-canvas-muted hover:text-white rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand"
            aria-label={mobileMenuOpen ? 'Fechar menu de navegação' : 'Abrir menu de navegação'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-surface-border bg-surface px-4 py-6 shadow-card animate-in fade-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col gap-4 text-base font-medium">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="py-2 text-canvas-muted hover:text-white border-b border-surface-border/50 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2 flex flex-col gap-3">
              <a
                href={BRAND_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between text-sm text-canvas-muted hover:text-white py-2"
              >
                <span>Siga nosso Instagram: {BRAND_INFO.instagramHandle}</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
              <a
                href={getWhatsAppLink('Olá! Gostaria de falar diretamente sobre meu projeto de site.')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full text-center py-3 bg-brand hover:bg-brand-hover text-white font-semibold rounded-lg text-sm transition-colors"
              >
                Conversar pelo WhatsApp
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
