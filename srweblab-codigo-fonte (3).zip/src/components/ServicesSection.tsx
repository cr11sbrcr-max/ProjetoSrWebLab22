import { useState } from 'react';
import { ArrowRight, CheckCircle2, Clock, Zap, Rocket, Shield, Globe2, Smartphone } from 'lucide-react';
import { SERVICES_LIST, getWhatsAppLink } from '../data/content';

export function ServicesSection() {
  const [showHowItWorksModal, setShowHowItWorksModal] = useState(false);

  return (
    <section id="servicos" className="py-20 lg:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <div className="text-xs font-bold uppercase tracking-widest text-brand mb-3">
              02. Soluções Especializadas
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight [text-wrap:balance]">
              Criação de Sites projetados para faturar
            </h2>
            <p className="text-base sm:text-lg text-canvas-muted mt-4">
              Cada estrutura de página é pensada detalhadamente para guiar a atenção do seu cliente, quebrar objeções e acelerar o fechamento de novos negócios.
            </p>
          </div>

          {/* Interactive Trigger for the Same-Day Delivery workflow */}
          <button
            type="button"
            onClick={() => setShowHowItWorksModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-brand/40 bg-brand-subtle text-white hover:bg-brand/20 transition-colors text-xs sm:text-sm font-semibold whitespace-nowrap self-start md:self-auto"
          >
            <Clock className="w-4 h-4 text-brand" aria-hidden="true" />
            <span>Como funciona a Entrega no Mesmo Dia?</span>
          </button>
        </div>

        {/* Bento Grid Layout of Services */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {SERVICES_LIST.map((service, index) => {
            // Give prominence to the first marquee item with col-span-7 and others with col-span-5
            const isMarquee = service.isHighlight;
            const colSpan = isMarquee ? 'lg:col-span-7' : index === 1 ? 'lg:col-span-5' : index === 2 ? 'lg:col-span-5' : 'lg:col-span-7';

            return (
              <div
                key={service.id}
                className={`${colSpan} group relative rounded-2xl p-6 sm:p-8 bg-surface border border-surface-border hover:border-brand/50 transition-all duration-300 shadow-card flex flex-col justify-between`}
              >
                {/* Header row inside card */}
                <div>
                  <div className="flex items-center justify-between gap-4 mb-4">
                    <span className="text-xs font-semibold tracking-wider text-canvas-muted uppercase">
                      {service.category}
                    </span>
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand bg-brand-subtle px-2.5 py-1 rounded border border-brand/20">
                      <Zap className="w-3 h-3" />
                      {service.deliveryTime}
                    </span>
                  </div>

                  <h3 className="font-display text-2xl font-bold text-white group-hover:text-brand transition-colors mb-3">
                    {service.title}
                  </h3>

                  <p className="text-sm sm:text-base text-canvas-muted leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Bullet features */}
                  <ul className="space-y-2.5 mb-8">
                    {service.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-canvas-text/90">
                        <CheckCircle2 className="w-4 h-4 text-brand shrink-0 mt-0.5" aria-hidden="true" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Footer action inside card */}
                <div className="pt-6 border-t border-surface-border/60 flex items-center justify-between">
                  <span className="text-xs text-canvas-muted font-medium">
                    100% Responsivo e Otimizado
                  </span>
                  <a
                    href={getWhatsAppLink(`Olá! Tenho interesse no serviço de ${service.title} com a S&R WebLab.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-brand hover:text-white transition-colors"
                  >
                    <span>Quero este modelo</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            );
          })}

        </div>

      </div>

      {/* Same-day delivery explanation modal */}
      {showHowItWorksModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-canvas/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
        >
          <div className="bg-surface border border-surface-border rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-elevated animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-surface-border mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-brand-subtle text-brand">
                  <Clock className="w-5 h-5" />
                </div>
                <h4 id="modal-title" className="font-display text-lg font-bold text-white">
                  Entrega no Mesmo Dia (24h)
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowHowItWorksModal(false)}
                className="text-canvas-muted hover:text-white p-1 rounded-lg"
                aria-label="Fechar janela informativa"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-sm text-canvas-text mb-6">
              <p className="text-canvas-muted">
                Nosso diferencial competitivo é responder à urgência do seu negócio sem sacrificar elegância ou código limpo:
              </p>
              
              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-graphite-dark/60 border border-surface-border">
                  <span className="font-bold text-white block">1. Briefing Direto & Acelerado</span>
                  <span className="text-xs text-canvas-muted">Alinhamento instantâneo via WhatsApp sobre seu nicho, ofertas e paleta.</span>
                </div>
                <div className="p-3 rounded-lg bg-graphite-dark/60 border border-surface-border">
                  <span className="font-bold text-white block">2. Engenharia Modular de Alta Conversão</span>
                  <span className="text-xs text-canvas-muted">Utilizamos arquitetura pré-otimizada para velocidade e copy persuasivo validado.</span>
                </div>
                <div className="p-3 rounded-lg bg-graphite-dark/60 border border-surface-border">
                  <span className="font-bold text-white block">3. Publicação Imediata com Domínio</span>
                  <span className="text-xs text-canvas-muted">Deploy seguro com SSL ativo e botões direcionando direto para sua equipe no mesmo dia.</span>
                </div>
              </div>
            </div>

            <div className="flex gap-3 justify-end">
              <button
                type="button"
                onClick={() => setShowHowItWorksModal(false)}
                className="px-4 py-2 text-xs font-semibold text-canvas-muted hover:text-white rounded-lg transition-colors"
              >
                Entendi
              </button>
              <a
                href={getWhatsAppLink('Olá! Preciso de um site pronto ainda hoje para minha empresa.')}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2 text-xs font-bold text-white bg-brand hover:bg-brand-hover rounded-lg transition-colors"
              >
                Solicitar com Entrega Hoje
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
