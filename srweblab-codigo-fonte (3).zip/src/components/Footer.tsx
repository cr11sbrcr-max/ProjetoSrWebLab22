import { ArrowUp, Instagram, MessageCircle, MapPin, Mail, Clock } from 'lucide-react';
import { BRAND_INFO, getWhatsAppLink } from '../data/content';
import { Logo } from './Logo';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-canvas border-t border-brand/20 text-canvas-muted text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Brand Column (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex flex-col items-start gap-1">
              <Logo size="md" showSubtitle={true} />
            </div>

            <p className="text-canvas-muted text-sm leading-relaxed max-w-sm mt-3">
              Tecnologia que coloca seu negócio em outro nível. Sites modernos, rápidos e feitos para gerar resultados imediatos para sua empresa.
            </p>

            <div className="pt-2 flex items-center gap-4">
              <a
                href={BRAND_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-lg bg-surface border border-surface-border text-canvas-text hover:text-brand hover:border-brand/40 transition-colors"
                aria-label="Instagram da S&R WebLab"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 rounded-lg bg-surface border border-surface-border text-canvas-text hover:text-brand hover:border-brand/40 transition-colors"
                aria-label="WhatsApp da S&R WebLab"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div>
            <span className="font-display text-sm font-bold text-white uppercase tracking-wider block mb-4">
              Navegação
            </span>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">Sobre a Agência</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Criação de Sites</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">Projetos & Portfólio</a>
              </li>
              <li>
                <a href="#planos" className="hover:text-white transition-colors">Planos & Preços</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">Solicitar Orçamento</a>
              </li>
            </ul>
          </div>

          {/* Services Quicklist */}
          <div>
            <span className="font-display text-sm font-bold text-white uppercase tracking-wider block mb-4">
              Serviços
            </span>
            <ul className="space-y-2.5 text-xs">
              <li>
                <span className="text-canvas-text font-medium">Landing Pages de Conversão</span>
              </li>
              <li>
                <span className="text-canvas-text font-medium">Sites Institucionais</span>
              </li>
              <li>
                <span className="text-canvas-text font-medium">Lojas Virtuais & E-commerce</span>
              </li>
              <li>
                <span className="text-brand font-semibold flex items-center gap-1 mt-1">
                  <Clock className="w-3 h-3" />
                  Entrega no Mesmo Dia
                </span>
              </li>
            </ul>
          </div>

          {/* Direct Contact & Details */}
          <div>
            <span className="font-display text-sm font-bold text-white uppercase tracking-wider block mb-4">
              Atendimento
            </span>
            <ul className="space-y-3 text-xs">
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-brand shrink-0" />
                <span>Atuação em todo o {BRAND_INFO.region}</span>
              </li>
              <li className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-brand shrink-0" />
                <a 
                  href={getWhatsAppLink()} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors font-medium text-canvas-text"
                >
                  WhatsApp: {BRAND_INFO.phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Instagram className="w-4 h-4 text-brand shrink-0" />
                <a 
                  href={BRAND_INFO.instagramUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  {BRAND_INFO.instagramHandle}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-brand shrink-0" />
                <span>{BRAND_INFO.email}</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Quiet Sub-footer */}
        <div className="pt-8 border-t border-surface-border flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-canvas-muted">
          <div>
            © {new Date().getFullYear()} {BRAND_INFO.name}. Todos os direitos reservados.
          </div>

          <div className="flex items-center gap-4">
            <span>Brasil</span>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={scrollToTop}
              className="inline-flex items-center gap-1 text-canvas-muted hover:text-white transition-colors"
              aria-label="Voltar ao topo da página"
            >
              <span>Voltar ao topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
