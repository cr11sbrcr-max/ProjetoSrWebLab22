import { useState } from 'react';
import { Send, CheckCircle2, MessageCircle, Clock, ShieldCheck, Sparkles } from 'lucide-react';
import { BRAND_INFO, getWhatsAppLink } from '../data/content';
import { ContactFormData } from '../types';

export function ContactSection() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    phone: '',
    company: '',
    serviceType: 'Landing Page de Alta Conversão',
    urgency: 'same_day',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Por favor, informe seu nome completo.';
    if (!formData.phone.trim() || formData.phone.length < 8) {
      errs.phone = 'Informe um WhatsApp válido para contato com DDD.';
    }
    if (!formData.company.trim()) {
      errs.company = 'Informe o nome da sua empresa ou nicho de atuação.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitted(true);
  };

  const generateWhatsAppMessage = () => {
    const urgencyLabel = formData.urgency === 'same_day' ? '🚨 URGENTE: Entrega no Mesmo Dia (24h)' : 'Prazo Convencional';
    return `*Solicitação de Site - S&R WebLab*
*Nome:* ${formData.name}
*WhatsApp:* ${formData.phone}
*Empresa/Nicho:* ${formData.company}
*Tipo de Projeto:* ${formData.serviceType}
*Prioridade:* ${urgencyLabel}
${formData.message ? `*Detalhes:* ${formData.message}` : ''}

Gostaria de receber uma proposta e iniciar meu site!`;
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      name: '',
      phone: '',
      company: '',
      serviceType: 'Landing Page de Alta Conversão',
      urgency: 'same_day',
      message: '',
    });
  };

  return (
    <section id="contato" className="py-20 lg:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-bold uppercase tracking-widest text-brand mb-3">
            04. Dê o Próximo Passo
          </div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight [text-wrap:balance]">
            Solicitar um site para minha empresa
          </h2>
          <p className="text-base sm:text-lg text-canvas-muted mt-4">
            Preencha os dados abaixo para receber uma análise técnica preliminar e iniciar seu projeto. Se tiver pressa, escolha a opção de entrega no mesmo dia.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Form Container (7 cols) */}
          <div className="lg:col-span-7 bg-surface border border-surface-border rounded-2xl p-6 sm:p-10 shadow-card">
            
            {submitted ? (
              <div className="text-center py-8 space-y-6 animate-in fade-in duration-300">
                <div className="w-16 h-16 rounded-full bg-brand-subtle border border-brand/40 text-brand flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-display text-2xl font-bold text-white mb-2">
                    Solicitação Registrada com Sucesso!
                  </h3>
                  <p className="text-canvas-muted text-sm max-w-md mx-auto">
                    Recebemos seus dados para a empresa <strong className="text-white">{formData.company}</strong>. Clique no botão abaixo para enviar o resumo diretamente no WhatsApp da S&R WebLab e acelerar o início do seu site.
                  </p>
                </div>

                {/* Direct WhatsApp Forward */}
                <div className="p-4 rounded-xl bg-graphite-dark border border-surface-border max-w-md mx-auto text-left text-xs space-y-1.5 text-canvas-text">
                  <div className="text-brand font-semibold uppercase text-[11px]">Resumo do Pedido:</div>
                  <div><strong>Responsável:</strong> {formData.name}</div>
                  <div><strong>Tipo de Site:</strong> {formData.serviceType}</div>
                  <div><strong>Prioridade:</strong> {formData.urgency === 'same_day' ? 'Entrega no Mesmo Dia (24h)' : 'Normal'}</div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
                  <a
                    href={getWhatsAppLink(generateWhatsAppMessage())}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 text-sm font-bold text-white bg-brand hover:bg-brand-hover rounded-xl shadow-brand-glow transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Confirmar no WhatsApp Oficial</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleReset}
                    className="w-full sm:w-auto px-5 py-3 text-xs font-semibold text-canvas-muted hover:text-white transition-colors"
                  >
                    Enviar nova solicitação
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-xs font-bold uppercase tracking-wider text-canvas-muted mb-2">
                      Seu Nome Completo *
                    </label>
                    <input
                      type="text"
                      id="name"
                      required
                      placeholder="Ex: Carlos Eduardo"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-graphite-dark border border-surface-border text-white placeholder-canvas-muted/50 focus:border-brand focus:ring-1 focus:ring-brand outline-none text-sm transition-colors"
                    />
                    {errors.name && <p className="text-xs text-rose-400 mt-1">{errors.name}</p>}
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-xs font-bold uppercase tracking-wider text-canvas-muted mb-2">
                      WhatsApp com DDD *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      required
                      placeholder="Ex: (24) 99999-9999"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-graphite-dark border border-surface-border text-white placeholder-canvas-muted/50 focus:border-brand focus:ring-1 focus:ring-brand outline-none text-sm transition-colors"
                    />
                    {errors.phone && <p className="text-xs text-rose-400 mt-1">{errors.phone}</p>}
                  </div>
                </div>

                {/* Company & Segment */}
                <div>
                  <label htmlFor="company" className="block text-xs font-bold uppercase tracking-wider text-canvas-muted mb-2">
                    Nome da Empresa & Nicho de Atuação *
                  </label>
                  <input
                    type="text"
                    id="company"
                    required
                    placeholder="Ex: Clínica Alpha / Estética e Saúde"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-graphite-dark border border-surface-border text-white placeholder-canvas-muted/50 focus:border-brand focus:ring-1 focus:ring-brand outline-none text-sm transition-colors"
                  />
                  {errors.company && <p className="text-xs text-rose-400 mt-1">{errors.company}</p>}
                </div>

                {/* Service Type Selection */}
                <div>
                  <label htmlFor="serviceType" className="block text-xs font-bold uppercase tracking-wider text-canvas-muted mb-2">
                    Tipo de Site Desejado
                  </label>
                  <select
                    id="serviceType"
                    value={formData.serviceType}
                    onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-graphite-dark border border-surface-border text-white focus:border-brand focus:ring-1 focus:ring-brand outline-none text-sm transition-colors"
                  >
                    <option value="Site Simples (R$ 150,00)">Site Simples — R$ 150,00 (Plano Ideal Para Começar)</option>
                    <option value="Site Essencial (R$ 300,00)">Site Essencial — R$ 300,00 (Mais Funcionalidades e SEO)</option>
                    <option value="Site Premium (R$ 500,00)">Site Premium — R$ 500,00 (Tudo para Dominar o Digital)</option>
                    <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão Personalizada</option>
                    <option value="E-commerce ou Loja Virtual">E-commerce / Catálogo Online com Checkout</option>
                    <option value="Projeto Sob Medida">Projeto Sob Medida / Outro</option>
                  </select>
                </div>

                {/* Urgency Radio Selector: Same Day Delivery Focus */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-canvas-muted mb-2">
                    Prazo de Entrega Desejado
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label 
                      className={`cursor-pointer p-3.5 rounded-xl border flex items-center justify-between transition-all ${
                        formData.urgency === 'same_day'
                          ? 'bg-brand/10 border-brand text-white shadow-subtle'
                          : 'bg-graphite-dark border-surface-border text-canvas-muted hover:border-canvas-muted'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="radio"
                          name="urgency"
                          value="same_day"
                          checked={formData.urgency === 'same_day'}
                          onChange={() => setFormData({ ...formData, urgency: 'same_day' })}
                          className="accent-brand"
                        />
                        <div>
                          <span className="text-xs font-bold text-white block">Urgente: Entrego no Mesmo Dia</span>
                          <span className="text-[11px] text-brand">Entrega garantida em até 24h</span>
                        </div>
                      </div>
                      <Clock className="w-4 h-4 text-brand shrink-0" />
                    </label>

                    <label 
                      className={`cursor-pointer p-3.5 rounded-xl border flex items-center justify-between transition-all ${
                        formData.urgency === 'normal'
                          ? 'bg-brand/10 border-brand text-white shadow-subtle'
                          : 'bg-graphite-dark border-surface-border text-canvas-muted hover:border-canvas-muted'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="radio"
                          name="urgency"
                          value="normal"
                          checked={formData.urgency === 'normal'}
                          onChange={() => setFormData({ ...formData, urgency: 'normal' })}
                          className="accent-brand"
                        />
                        <div>
                          <span className="text-xs font-bold text-white block">Prazo Padrão</span>
                          <span className="text-[11px] text-canvas-muted">Cronograma flexível (3 a 7 dias)</span>
                        </div>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Additional notes */}
                <div>
                  <label htmlFor="message" className="block text-xs font-bold uppercase tracking-wider text-canvas-muted mb-2">
                    Detalhes Adicionais (Opcional)
                  </label>
                  <textarea
                    id="message"
                    rows={3}
                    placeholder="Conte resumidamente o que você mais precisa no site ou deixe referências que gosta..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-graphite-dark border border-surface-border text-white placeholder-canvas-muted/50 focus:border-brand focus:ring-1 focus:ring-brand outline-none text-sm transition-colors resize-none"
                  />
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full py-4 px-6 text-sm sm:text-base font-bold text-white bg-brand hover:bg-brand-hover active:bg-brand-active rounded-xl shadow-brand-glow transition-all duration-200 flex items-center justify-center gap-2 group cursor-pointer"
                >
                  <span>Solicitar Proposta Agora</span>
                  <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <p className="text-center text-[11px] text-canvas-muted">
                  Seus dados estão protegidos. Resposta ágil diretamente pela equipe da S&R WebLab.
                </p>
              </form>
            )}

          </div>

          {/* Right Info & Direct Contact Channels (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="p-6 sm:p-8 rounded-2xl bg-surface border border-surface-border">
              <span className="text-xs font-bold uppercase tracking-wider text-brand block mb-2">
                Atendimento Imediato
              </span>
              <h3 className="font-display text-xl font-bold text-white mb-4">
                Prefere conversar diretamente pelo WhatsApp?
              </h3>
              <p className="text-xs sm:text-sm text-canvas-muted leading-relaxed mb-6">
                Se você não quer preencher formulário e precisa de atendimento ágil para tirar dúvidas ou reservar a produção do seu site com entrega expressa, fale agora conosco:
              </p>

              <a
                href={getWhatsAppLink('Olá! Gostaria de falar diretamente com a S&R WebLab sobre a criação de um site para minha empresa.')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors shadow-subtle"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Conversar no WhatsApp ({BRAND_INFO.phoneDisplay})</span>
              </a>
            </div>

            <div className="p-6 rounded-2xl bg-surface/50 border border-surface-border space-y-4">
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-brand shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">
                    Disponibilidade Express
                  </div>
                  <div className="text-xs text-canvas-muted mt-0.5">
                    Projetos com entrega no mesmo dia possuem vagas diárias limitadas para assegurar perfeição nos detalhes.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-white uppercase tracking-wider">
                    Suporte e Hospedagem Inclusos
                  </div>
                  <div className="text-xs text-canvas-muted mt-0.5">
                    Orientamos sobre domínio, hospedagem ultrarrápida e colocamos sua página no ar sem complicação técnica para você.
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
