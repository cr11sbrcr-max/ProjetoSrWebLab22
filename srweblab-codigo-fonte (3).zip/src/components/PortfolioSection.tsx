import { useState } from 'react';
import { ArrowUpRight, TrendingUp, Clock, Eye, X, CheckCircle } from 'lucide-react';
import { PORTFOLIO_PROJECTS, getWhatsAppLink } from '../data/content';
import { PortfolioProject } from '../types';

export function PortfolioSection() {
  const [selectedFilter, setSelectedFilter] = useState<string>('todos');
  const [activeProjectModal, setActiveProjectModal] = useState<PortfolioProject | null>(null);

  const filters = [
    { id: 'todos', label: 'Todos os Projetos' },
    { id: 'B2B & Finanças', label: 'B2B & Finanças' },
    { id: 'Moda & Luxo', label: 'E-commerce' },
    { id: 'Serviços Corporativos', label: 'Corporativo' },
  ];

  const filteredProjects = selectedFilter === 'todos'
    ? PORTFOLIO_PROJECTS
    : PORTFOLIO_PROJECTS.filter((p) => p.segment === selectedFilter);

  return (
    <section id="portfolio" className="py-20 lg:py-28 bg-canvas-subtle border-y border-canvas-border relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <div className="text-xs font-bold uppercase tracking-widest text-brand mb-3">
              03. Portfólio e Casos de Sucesso
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight [text-wrap:balance]">
              Resultados reais que aceleram o faturamento
            </h2>
            <p className="text-base sm:text-lg text-canvas-muted mt-4">
              Explore projetos recentes desenvolvidos com design de alto padrão, velocidade de carregamento incomparável e arquitetura focada em conversão.
            </p>
          </div>

          {/* Interactive Filter Tabs (Constitution: clean segmented control) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-surface rounded-xl border border-surface-border self-start md:self-auto" role="tablist" aria-label="Filtrar projetos por segmento">
            {filters.map((tab) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={selectedFilter === tab.id}
                onClick={() => setSelectedFilter(tab.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-all duration-200 whitespace-nowrap ${
                  selectedFilter === tab.id
                    ? 'bg-brand text-white shadow-subtle'
                    : 'text-canvas-muted hover:text-white hover:bg-surface-hover'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <article
              key={project.id}
              className="group rounded-2xl bg-surface border border-surface-border hover:border-brand/50 transition-all duration-300 overflow-hidden shadow-card flex flex-col"
            >
              {/* Image Preview with Hover Reveal */}
              <div className="relative aspect-[4/3] overflow-hidden bg-graphite-dark">
                <img
                  src={project.image}
                  alt={`Mockup do projeto ${project.title} desenvolvido pela S&R WebLab`}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500 ease-out"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  onError={(e) => {
                    // Fallback container if local asset failed
                    const target = e.currentTarget;
                    target.style.display = 'none';
                    const parent = target.parentElement;
                    if (parent) {
                      parent.classList.add('flex', 'items-center', 'justify-center', 'bg-gradient-to-br', 'from-surface', 'to-canvas');
                      parent.innerHTML = `<span class="text-xs font-bold text-brand uppercase tracking-wider">${project.title}</span>`;
                    }
                  }}
                />

                {/* Scrim Overlay */}
                <div 
                  className="absolute inset-0 bg-gradient-to-t from-surface via-surface/20 to-transparent pointer-events-none" 
                  aria-hidden="true" 
                />

                {/* Floating Metric Badge */}
                <div className="absolute top-3.5 right-3.5 px-3 py-1.5 rounded-lg bg-canvas/90 backdrop-blur-md border border-brand/30 flex items-center gap-1.5 shadow-subtle">
                  <TrendingUp className="w-3.5 h-3.5 text-brand" />
                  <span className="font-display text-xs font-extrabold text-white tabular-nums">
                    {project.metric}
                  </span>
                  <span className="text-[10px] text-canvas-muted hidden sm:inline">
                    {project.metricLabel}
                  </span>
                </div>

                {/* Delivery Tag */}
                <div className="absolute bottom-3.5 left-3.5 px-2.5 py-1 rounded bg-graphite-dark/80 backdrop-blur-md border border-surface-border text-[11px] text-canvas-text flex items-center gap-1">
                  <Clock className="w-3 h-3 text-brand" />
                  <span>{project.deliverySpeed}</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  {/* Clean unboxed metadata with separators (Zero-pill discipline) */}
                  <div className="flex items-center gap-2 text-xs text-canvas-muted mb-2 font-medium">
                    <span>{project.client}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-brand">{project.segment}</span>
                  </div>

                  <h3 className="font-display text-xl font-bold text-white group-hover:text-brand transition-colors mb-2">
                    {project.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-canvas-muted leading-relaxed mb-4">
                    {project.description}
                  </p>

                  {/* Clean list of technologies/tags */}
                  <div className="flex flex-wrap items-center gap-1.5 text-xs text-canvas-muted">
                    {project.tags.map((tag, tIdx) => (
                      <span key={tIdx} className="text-[11px] px-2 py-0.5 rounded bg-canvas-subtle border border-surface-border text-canvas-text">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Interactive modal trigger */}
                <div className="pt-6 mt-6 border-t border-surface-border flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setActiveProjectModal(project)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-white hover:text-brand transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Ver detalhes do projeto</span>
                  </button>

                  <a
                    href={getWhatsAppLink(`Olá! Vi o projeto ${project.title} no portfólio da S&R WebLab e quero um site no mesmo padrão.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-brand hover:text-white rounded-lg hover:bg-surface-hover transition-colors"
                    aria-label={`Solicitar site similar a ${project.title}`}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Global Portfolio CTA */}
        <div className="mt-16 text-center">
          <p className="text-sm text-canvas-muted mb-4">
            Deseja uma estrutura exclusiva adaptada ao nicho da sua empresa?
          </p>
          <a
            href={getWhatsAppLink('Olá! Gostaria de ver mais modelos e conversar sobre o site para o meu nicho.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-bold text-white bg-surface hover:bg-surface-hover border border-surface-border hover:border-brand/40 rounded-xl transition-all"
          >
            <span>Solicitar proposta para o meu nicho</span>
            <ArrowUpRight className="w-4 h-4 text-brand" />
          </a>
        </div>

      </div>

      {/* Project Details Modal */}
      {activeProjectModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-canvas/85 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="project-modal-title"
        >
          <div className="bg-surface border border-surface-border rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-elevated animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-start justify-between pb-4 border-b border-surface-border mb-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-brand">
                  {activeProjectModal.segment}
                </span>
                <h4 id="project-modal-title" className="font-display text-2xl font-bold text-white mt-1">
                  {activeProjectModal.title}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setActiveProjectModal(null)}
                className="text-canvas-muted hover:text-white p-2 rounded-lg bg-surface-hover"
                aria-label="Fechar detalhes"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="aspect-[16/9] rounded-xl overflow-hidden mb-6 bg-graphite-dark border border-surface-border">
              <img
                src={activeProjectModal.image}
                alt={activeProjectModal.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="space-y-4 mb-8">
              <div className="p-4 rounded-xl bg-graphite-dark/60 border border-surface-border flex items-center justify-between">
                <div>
                  <span className="text-xs text-canvas-muted">Métrica de Impacto Comprovada:</span>
                  <div className="font-display text-2xl font-bold text-white">
                    {activeProjectModal.metric}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs text-canvas-muted">Velocidade de Execução:</span>
                  <div className="text-sm font-semibold text-brand">
                    {activeProjectModal.deliverySpeed}
                  </div>
                </div>
              </div>

              <p className="text-sm text-canvas-text leading-relaxed">
                {activeProjectModal.description}
              </p>

              <div className="space-y-2">
                <span className="text-xs font-semibold text-white block uppercase tracking-wide">
                  Principais diferenciais aplicados no projeto:
                </span>
                <ul className="space-y-1.5 text-xs text-canvas-muted">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-brand" />
                    <span>Copywriting persuasivo e foco em quebra de objeções</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-brand" />
                    <span>Integração de WhatsApp comercial com respostas automáticas</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-brand" />
                    <span>Código leve, responsivo e com alta taxa de retenção</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-surface-border">
              <button
                type="button"
                onClick={() => setActiveProjectModal(null)}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-canvas-muted hover:text-white rounded-lg transition-colors"
              >
                Voltar
              </button>
              <a
                href={getWhatsAppLink(`Olá! Gostaria de um projeto no estilo de ${activeProjectModal.title} para a minha empresa.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs sm:text-sm font-bold text-white bg-brand hover:bg-brand-hover rounded-lg shadow-brand-glow transition-all"
              >
                <span>Solicitar site como este</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
