import { useState } from 'react';
import { 
  Check, 
  ShieldCheck, 
  Gauge, 
  Smartphone, 
  Headphones, 
  Rocket, 
  ArrowRight,
  Monitor,
  ExternalLink
} from 'lucide-react';
import { OFFICIAL_PLANS, TRUST_BENEFITS, getWhatsAppLink, BRAND_INFO } from '../data/content';
import { Logo } from './Logo';

export function PricingSection() {
  const [hoveredPlan, setHoveredPlan] = useState<string | null>(null);

  const scrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const contactElem = document.querySelector('#contato');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="planos" className="py-20 lg:py-28 bg-[#070709] border-t border-brand/20 relative overflow-hidden">
      {/* Ambient background glow matching the vibrant orange aura of the reference */}
      <div 
        className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-brand/12 rounded-full blur-[120px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Brand Header directly inspired by top of user image */}
        <div className="flex flex-col items-center text-center mb-16">
          <Logo size="lg" showSubtitle={true} className="mb-6" />

          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight uppercase [text-wrap:balance]">
            ESCOLHA O PLANO IDEAL PARA O SEU NEGÓCIO
          </h2>
          <p className="text-base sm:text-lg text-canvas-muted mt-3 font-medium">
            Sites modernos, rápidos e feitos para gerar resultados.
          </p>
        </div>

        {/* 3 Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch mb-16">
          {OFFICIAL_PLANS.map((plan) => {
            const isHovered = hoveredPlan === plan.id;
            
            return (
              <div
                key={plan.id}
                onMouseEnter={() => setHoveredPlan(plan.id)}
                onMouseLeave={() => setHoveredPlan(null)}
                className={`group relative rounded-2xl p-6 sm:p-8 bg-[#0D0D10] border-2 border-brand transition-all duration-300 flex flex-col justify-between shadow-card hover:shadow-brand-glow hover:-translate-y-1.5 ${
                  plan.isPopular ? 'shadow-brand-glow ring-1 ring-brand/50' : ''
                }`}
              >
                {/* Card Top Information */}
                <div>
                  {/* Plan Name */}
                  <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-wide text-center uppercase mb-3">
                    {plan.name}
                  </h3>

                  {/* Price */}
                  <div className="flex items-center justify-center text-white font-extrabold my-2">
                    <span className="font-display text-2xl sm:text-3xl font-bold text-white mr-1">R$</span>
                    <span className="font-display text-5xl sm:text-6xl tracking-tight text-white tabular-nums">
                      {plan.price}
                    </span>
                    <span className="font-display text-2xl sm:text-3xl font-bold text-white">
                      {plan.cents}
                    </span>
                  </div>

                  {/* Orange Pill Banner from image */}
                  <div className="my-5 flex justify-center">
                    <div className="w-full text-center py-2 px-3 rounded-full bg-brand text-black font-extrabold text-[11px] sm:text-xs uppercase tracking-wider shadow-subtle">
                      {plan.bannerText}
                    </div>
                  </div>

                  {/* Bullet features with orange checkmark */}
                  <ul className="space-y-3.5 my-6 text-left">
                    {plan.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-3 text-xs sm:text-sm text-gray-200">
                        <span className="w-4 h-4 rounded-sm flex items-center justify-center text-brand shrink-0 mt-0.5 font-bold text-base leading-none">
                          ✔
                        </span>
                        <span className="leading-snug">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Bottom: Device Mockup and CTA */}
                <div>
                  {/* Device Mockup Preview (as present in the reference image) */}
                  <div className="relative my-6 p-3 rounded-xl bg-[#08080A] border border-brand/30 group-hover:border-brand/60 transition-colors">
                    <div className="aspect-[16/10] rounded-lg bg-[#141418] p-2 flex flex-col justify-between overflow-hidden relative border border-white/10">
                      
                      {/* Laptop mockup screen header */}
                      <div className="flex items-center justify-between pb-1.5 border-b border-white/10 text-[9px] text-gray-400">
                        <div className="flex items-center gap-1 font-bold text-white">
                          <span className="text-[10px] text-brand">SR</span>
                          <span className="text-[8px] text-gray-400">webLab</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-8 h-1 bg-white/20 rounded"></span>
                          <span className="w-6 h-1 bg-white/20 rounded"></span>
                          <span className="w-4 h-1 bg-brand rounded"></span>
                        </div>
                      </div>

                      {/* Screen content */}
                      <div className="py-2 text-left">
                        <div className="text-[11px] font-bold text-white leading-tight max-w-[130px]">
                          {plan.mockupTitle}
                        </div>
                        <div className="mt-2 inline-block px-2 py-0.5 rounded bg-brand text-black font-extrabold text-[9px]">
                          {plan.buttonText}
                        </div>
                      </div>

                      {/* Smartphone overlay mockup in corner */}
                      <div className="absolute right-2 bottom-1.5 w-14 aspect-[9/16] rounded-md bg-[#0A0A0C] border border-brand/60 p-1 flex flex-col justify-between shadow-card">
                        <div className="w-4 h-0.5 bg-white/30 rounded mx-auto"></div>
                        <div className="text-[6px] text-white font-bold leading-tight">
                          {plan.mockupTitle}
                        </div>
                        <div className="w-full py-0.5 bg-brand text-black font-bold text-[5px] text-center rounded">
                          {plan.buttonText}
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Direct WhatsApp Action Button */}
                  <a
                    href={getWhatsAppLink(`Olá! Gostaria de contratar o plano ${plan.name} (R$ ${plan.price}${plan.cents}) com a srwebLab.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3.5 px-4 rounded-xl text-xs sm:text-sm font-extrabold uppercase tracking-wider text-black bg-brand hover:bg-[#FF6E1A] active:bg-[#E04A00] flex items-center justify-center gap-2 transition-all duration-200 shadow-brand-glow"
                  >
                    <span>Quero o {plan.name}</span>
                    <ArrowRight className="w-4 h-4" />
                  </a>

                  <div className="text-center text-[10px] text-canvas-muted mt-2">
                    Início rápido com opção de entrega expressa
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* 4 Trust Benefits Bar (Matching the bottom of the user's uploaded image) */}
        <div className="pt-8 pb-10 border-t border-brand/30">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            
            {/* Benefit 1 */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 px-2">
              <div className="text-brand shrink-0">
                <ShieldCheck className="w-8 h-8" strokeWidth={1.75} />
              </div>
              <div className="text-left">
                <span className="block font-display text-xs sm:text-sm font-extrabold text-white tracking-wide">
                  SITES SEGUROS
                </span>
                <span className="block text-[11px] sm:text-xs text-canvas-muted">
                  com certificado SSL
                </span>
              </div>
            </div>

            {/* Benefit 2 */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 px-2 sm:border-l border-white/10">
              <div className="text-brand shrink-0">
                <Gauge className="w-8 h-8" strokeWidth={1.75} />
              </div>
              <div className="text-left">
                <span className="block font-display text-xs sm:text-sm font-extrabold text-white tracking-wide">
                  CARREGAMENTO
                </span>
                <span className="block text-[11px] sm:text-xs text-brand font-bold">
                  SUPER RÁPIDO
                </span>
              </div>
            </div>

            {/* Benefit 3 */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 px-2 md:border-l border-white/10">
              <div className="text-brand shrink-0">
                <Monitor className="w-8 h-8" strokeWidth={1.75} />
              </div>
              <div className="text-left">
                <span className="block font-display text-xs sm:text-sm font-extrabold text-white tracking-wide">
                  100% RESPONSIVO
                </span>
                <span className="block text-[11px] sm:text-xs text-canvas-muted">
                  em todos os dispositivos
                </span>
              </div>
            </div>

            {/* Benefit 4 */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 px-2 sm:border-l border-white/10">
              <div className="text-brand shrink-0">
                <Headphones className="w-8 h-8" strokeWidth={1.75} />
              </div>
              <div className="text-left">
                <span className="block font-display text-xs sm:text-sm font-extrabold text-white tracking-wide">
                  SUPORTE ESPECIALIZADO
                </span>
                <span className="block text-[11px] sm:text-xs text-canvas-muted">
                  antes e depois da entrega
                </span>
              </div>
            </div>

          </div>
        </div>

        {/* Big Glow CTA Button (Exact copy and style from bottom of the reference image) */}
        <div className="flex flex-col items-center justify-center pt-8 pb-4">
          <div className="w-full max-w-xl h-[1px] bg-gradient-to-r from-transparent via-brand/60 to-transparent mb-8" />

          <a
            href={getWhatsAppLink('Olá! Vi a tabela de planos da srwebLab e gostaria de solicitar um orçamento para o meu negócio.')}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative inline-flex items-center justify-center gap-3 px-8 sm:px-12 py-4 rounded-full border-2 border-brand bg-[#0C0C0E] hover:bg-brand text-brand hover:text-black font-display text-base sm:text-lg font-extrabold tracking-wider uppercase transition-all duration-300 shadow-brand-glow hover:shadow-brand-glow-lg"
          >
            <Rocket className="w-6 h-6 text-brand group-hover:text-black group-hover:-translate-y-0.5 transition-transform" />
            <span>SOLICITE SEU ORÇAMENTO</span>
          </a>

          <p className="text-xs text-canvas-muted mt-3">
            Atendimento direto e imediato pelo WhatsApp oficial: <strong className="text-white">{BRAND_INFO.phoneDisplay}</strong>
          </p>
        </div>

      </div>
    </section>
  );
}
