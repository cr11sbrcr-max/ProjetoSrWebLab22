import { ArrowRight, Clock, Zap, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { BRAND_INFO, getWhatsAppLink } from '../data/content';

export function HeroSection() {
  const scrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const contactSection = document.querySelector('#contato');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="inicio" className="relative pt-10 pb-20 lg:pt-16 lg:pb-32 overflow-hidden">
      {/* Background radial glow */}
      <div 
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand/10 rounded-full blur-3xl pointer-events-none -z-10" 
        aria-hidden="true" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Trust Kicker (Constitution compliant: clean unboxed text) */}
        <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-medium text-brand mb-6 tracking-wide">
          <span className="flex items-center gap-1.5 bg-brand text-black px-3 py-1 rounded-full font-extrabold uppercase tracking-wider text-[11px] shadow-subtle">
            <Zap className="w-3.5 h-3.5 fill-black" aria-hidden="true" />
            <span>SITES QUE GERAM RESULTADO</span>
          </span>
          <span className="text-canvas-muted" aria-hidden="true">·</span>
          <span className="text-canvas-text font-bold flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-brand" aria-hidden="true" />
            <span>{BRAND_INFO.differentiator}</span>
          </span>
          <span className="hidden sm:inline text-canvas-muted" aria-hidden="true">·</span>
          <span className="hidden sm:inline text-canvas-muted">Sites modernos, rápidos e de alta conversão</span>
        </div>

        {/* Main Grid: Copy on Left, High-Impact Media Showcase on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headlines & Persuasion */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] mb-6 [text-wrap:balance]">
              Tecnologia que coloca seu negócio em <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand via-orange-500 to-amber-400">outro nível</span>.
            </h1>

            <p className="text-lg sm:text-xl text-canvas-muted leading-relaxed mb-8 max-w-2xl">
              Criamos sites e landing pages de alto padrão, desenhados sob medida para transformar visitantes casuais em clientes pagantes com velocidade extrema.
            </p>

            {/* Main Action CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mb-10">
              <a
                href={getWhatsAppLink('Olá! Desejo solicitar um site para minha empresa com urgência e foco em aumentar meu faturamento.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 text-base font-extrabold uppercase tracking-wider text-black bg-brand hover:bg-brand-hover active:bg-brand-active rounded-xl shadow-brand-glow hover:shadow-brand-glow-lg transition-all duration-200 group text-center"
              >
                <span>{BRAND_INFO.primaryCtaText}</span>
                <ArrowRight className="w-5 h-5 text-black group-hover:translate-x-1 transition-transform" aria-hidden="true" />
              </a>

              <a
                href="#planos"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-base font-bold text-white hover:text-brand bg-[#0C0C0E] hover:bg-surface border-2 border-brand/40 hover:border-brand rounded-xl transition-all text-center"
              >
                Ver Planos (A partir de R$ 150)
              </a>
            </div>

            {/* Trust Markers Bar */}
            <div className="pt-6 border-t border-brand/20 w-full grid grid-cols-3 gap-4 text-left">
              <div>
                <div className="font-display text-2xl sm:text-3xl font-extrabold text-brand tabular-nums">24h</div>
                <div className="text-xs text-canvas-muted mt-0.5 font-medium">Opção de entrega no mesmo dia</div>
              </div>
              <div>
                <div className="font-display text-2xl sm:text-3xl font-extrabold text-white tabular-nums">100%</div>
                <div className="text-xs text-canvas-muted mt-0.5 font-medium">Otimizado para celular e tablet</div>
              </div>
              <div>
                <div className="font-display text-2xl sm:text-3xl font-extrabold text-brand tabular-nums">&lt; 1s</div>
                <div className="text-xs text-canvas-muted mt-0.5 font-medium">Velocidade máxima PageSpeed</div>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Agency Showcase Visual Container */}
          <div className="lg:col-span-5 relative w-full">
            <div className="relative rounded-2xl p-2 bg-[#0D0D10] border-2 border-brand shadow-brand-glow">
              
              {/* Media Container with Image */}
              <div className="relative aspect-[16/10] sm:aspect-[16/11] rounded-xl overflow-hidden bg-graphite-dark">
                <img
                  src="/src/assets/images/hero_agency_showcase_1791174448945.jpg"
                  alt="Estúdio criativo S&R WebLab com telas exibindo arquitetura de sites responsivos e de alta conversão"
                  className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                  loading="eager"
                />

                {/* Subtle scrim overlay */}
                <div 
                  className="absolute inset-0 bg-gradient-to-t from-graphite-dark/90 via-transparent to-transparent pointer-events-none"
                  aria-hidden="true" 
                />

                {/* Floating Micro Proof Overlay on Media */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 bg-surface/90 backdrop-blur-md rounded-lg border border-surface-border flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    <div>
                      <span className="block font-semibold text-white">S&R WebLab Core Engine</span>
                      <span className="block text-canvas-muted text-[11px]">Projetado para máxima performance</span>
                    </div>
                  </div>
                  <span className="text-brand font-semibold text-[11px] uppercase tracking-wider bg-brand-subtle px-2 py-1 rounded">
                    Alto Padrão
                  </span>
                </div>
              </div>

              {/* Decorative Corner Accent */}
              <div 
                className="absolute -top-3 -right-3 w-10 h-10 bg-brand/20 border border-brand/40 rounded-lg flex items-center justify-center text-brand"
                aria-hidden="true"
              >
                <Sparkles className="w-5 h-5" />
              </div>
            </div>

            {/* Quick Guarantee Callout */}
            <div className="mt-4 flex items-center gap-2 text-xs text-canvas-muted justify-center lg:justify-start">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" aria-hidden="true" />
              <span>Garantia de entrega no prazo acordado com suporte e acompanhamento técnico</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
