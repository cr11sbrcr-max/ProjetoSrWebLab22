import { Check, Layers, Cpu, Award } from 'lucide-react';
import { ABOUT_CONTENT, BRAND_INFO, getWhatsAppLink } from '../data/content';

export function AboutSection() {
  return (
    <section id="sobre" className="py-20 lg:py-28 bg-canvas-subtle border-y border-canvas-border relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="text-xs font-bold uppercase tracking-widest text-brand mb-3">
            01. Sobre a Marca
          </div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight mb-6 [text-wrap:balance]">
            {ABOUT_CONTENT.subtitle}
          </h2>
          <div className="w-16 h-1 bg-brand rounded-full mb-8" />
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Text Block with exact requested narrative */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-4 text-base sm:text-lg text-canvas-text/90 leading-relaxed">
              <p className="font-medium text-white text-xl">
                {ABOUT_CONTENT.paragraphs[0]}
              </p>
              <p className="text-canvas-muted">
                {ABOUT_CONTENT.paragraphs[1]}
              </p>
              <blockquote className="p-4 my-4 rounded-xl border-l-4 border-brand bg-surface/50 text-white font-display text-lg sm:text-xl font-semibold italic">
                "{ABOUT_CONTENT.paragraphs[2]}"
              </blockquote>
            </div>

            {/* Competitive Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-surface border border-surface-border">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg bg-brand-subtle text-brand">
                    <Layers className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <h3 className="font-display font-bold text-white text-base">Design e Funcionalidade</h3>
                </div>
                <p className="text-xs sm:text-sm text-canvas-muted leading-normal">
                  Projetos desenhados para conectar sua proposta única de valor ao desejo imediato de compra do cliente.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-surface border border-surface-border">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg bg-brand-subtle text-brand">
                    <Cpu className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <h3 className="font-display font-bold text-white text-base">Tecnologia que Escala</h3>
                </div>
                <p className="text-xs sm:text-sm text-canvas-muted leading-normal">
                  Código limpo, estruturado e veloz que pontua alto nos motores de busca do Google e carrega em segundos.
                </p>
              </div>
            </div>

            {/* Direct CTA */}
            <div className="pt-2">
              <a
                href={getWhatsAppLink('Olá! Gostaria de conversar com a equipe da S&R WebLab para entender como colocar meu negócio em outro nível.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-brand-hover group"
              >
                <span>Falar diretamente com um especialista agora</span>
                <span className="group-hover:translate-x-1 transition-transform" aria-hidden="true">→</span>
              </a>
            </div>
          </div>

          {/* Right Metrics & Differentials Panel */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl p-6 sm:p-8 bg-surface border border-surface-border shadow-card relative overflow-hidden">
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-surface-border">
                <div>
                  <span className="text-xs uppercase tracking-wider text-canvas-muted font-semibold">Compromisso S&R</span>
                  <h4 className="font-display text-xl font-bold text-white">Padrões de Entrega</h4>
                </div>
                <div className="p-2 rounded-lg bg-brand text-white">
                  <Award className="w-6 h-6" aria-hidden="true" />
                </div>
              </div>

              {/* Stats List */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                {ABOUT_CONTENT.stats.map((stat, idx) => (
                  <div key={idx} className="border-l-2 border-brand/40 pl-3">
                    <div className="font-display text-3xl font-extrabold text-white tabular-nums">
                      {stat.value}
                    </div>
                    <div className="text-xs font-semibold text-canvas-text mt-1">
                      {stat.label}
                    </div>
                    <div className="text-[11px] text-canvas-muted">
                      {stat.caption}
                    </div>
                  </div>
                ))}
              </div>

              {/* Differential Banner */}
              <div className="p-4 rounded-xl bg-graphite-dark/80 border border-brand/30">
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-brand text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white uppercase tracking-wider">
                      Diferencial Competitivo
                    </div>
                    <div className="text-sm font-semibold text-brand mt-0.5">
                      "Entrego no mesmo dia"
                    </div>
                    <p className="text-xs text-canvas-muted mt-1 leading-normal">
                      Metodologia ágil e focada que permite colocar sua campanha ou apresentação no ar em 24h sem perder qualidade estética.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
