import { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { BRAND_INFO, getWhatsAppLink } from '../data/content';

export function FloatingWhatsApp() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <aside 
      aria-label="Atendimento via WhatsApp"
      className="fixed bottom-6 right-6 z-50 flex flex-col items-end"
    >
      {/* Interactive Tooltip Card */}
      {isOpen && (
        <div className="mb-3 w-72 sm:w-80 p-4 bg-surface border border-surface-border rounded-2xl shadow-elevated animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-surface-border mb-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="font-display font-bold text-xs text-white uppercase tracking-wider">
                {BRAND_INFO.name}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="text-canvas-muted hover:text-white p-1 rounded-md"
              aria-label="Fechar popover do WhatsApp"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-canvas-muted leading-relaxed mb-4">
            Olá! Está precisando de um site profissional para aumentar o faturamento da sua empresa ou quer uma entrega expressa hoje?
          </p>

          <a
            href={getWhatsAppLink('Olá! Gostaria de conversar agora sobre o site para minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors shadow-subtle"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Iniciar Conversa Agora</span>
          </a>
        </div>
      )}

      {/* Floating Action Button */}
      <div className="relative group">
        <a
          href={getWhatsAppLink('Olá! Gostaria de solicitar um site para minha empresa com a S&R WebLab.')}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Conversar pelo WhatsApp da S&R WebLab"
          className="flex items-center justify-center w-14 h-14 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-full shadow-elevated hover:scale-105 active:scale-95 transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:ring-offset-2 focus-visible:ring-offset-canvas"
        >
          <MessageCircle className="w-7 h-7" aria-hidden="true" />
          
          {/* Online green indicator badge */}
          <span 
            className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-400 border-2 border-surface rounded-full"
            aria-hidden="true" 
          />
        </a>

        {/* Desktop Quick Tooltip on Hover */}
        <div className="hidden lg:group-hover:flex absolute right-16 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-surface text-white text-xs font-semibold rounded-lg shadow-card border border-surface-border whitespace-nowrap pointer-events-none transition-opacity">
          Fale no WhatsApp
        </div>
      </div>
    </aside>
  );
}
