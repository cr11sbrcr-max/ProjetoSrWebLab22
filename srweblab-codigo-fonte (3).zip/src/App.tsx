import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { ContactSection } from './components/ContactSection';
import { PricingSection } from './components/PricingSection';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-canvas text-canvas-text flex flex-col font-body selection:bg-brand selection:text-white">
      {/* Top Bar Navigation */}
      <Header />

      {/* Main Content Sections strictly in requested order */}
      <main id="main-content" className="flex-1">
        {/* 1. Seção inicial impactante */}
        <HeroSection />

        {/* 2. Sobre / Quem sou */}
        <AboutSection />

        {/* 3. Serviços */}
        <ServicesSection />

        {/* 4. Portfólio / Projetos */}
        <PortfolioSection />

        {/* 5. Formulário de contato */}
        <ContactSection />

        {/* 7. Preços / Planos */}
        <PricingSection />
      </main>

      {/* 6. WhatsApp flutuante */}
      <FloatingWhatsApp />

      {/* Footer */}
      <Footer />
    </div>
  );
}
